package com.fit.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.fit.entity.Xe;

@Repository
public class XeDaoImpl implements XeDao{
	
	@Autowired
	private SessionFactory sessionFactory;
	
	@Override
	public void saveXe(Xe theXe) {
		Session currentSession = sessionFactory.getCurrentSession();
		currentSession.saveOrUpdate(theXe);
	}

	@Override
	public void deleteXe(int theId) {
		Session currentSession = sessionFactory.getCurrentSession();
		Query theQuery = currentSession.createQuery("delete from Xe where id =: xeId");
		theQuery.setParameter("xeId", theId);
		theQuery.executeUpdate();
	}

	@Override
	public Xe getXe(int theId) {
		Session currentSession = sessionFactory.getCurrentSession();
		Xe theXe = currentSession.get(Xe.class, theId);
		return theXe;
	}

	@Override
	@Transactional
	public List<Xe> getXes() {
		Session currentSession = sessionFactory.getCurrentSession();
		Query<Xe> theQuery = currentSession.createQuery("from Xe order by id", Xe.class);
		List<Xe> listXe = theQuery.getResultList();
		return listXe;
	}

}
