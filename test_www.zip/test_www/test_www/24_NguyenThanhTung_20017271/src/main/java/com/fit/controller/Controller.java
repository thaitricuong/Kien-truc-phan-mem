package com.fit.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.fit.entity.Xe;
import com.fit.service.XeService;

@org.springframework.stereotype.Controller
@RequestMapping("/xe")
public class Controller {
	
	@Autowired
	private XeService xeService;
	
	@PostMapping("/saveXe")
	public String saveXe(@ModelAttribute("xe") Xe theXe) {
		xeService.saveXe(theXe);
		return "redirect:/xe/list";
	}
	@GetMapping("/showFornForUpdate")
	public String showFornForUpdate(@RequestParam("xeId") int theId, Model theModel) {
		Xe theXe = xeService.getXe(theId);
		theModel.addAttribute("xe", theXe);
		return "xe-form";
	}
	@GetMapping("showFornForAdd")
	public String showFornForAdd(Model theModel) {
		Xe theXe = new Xe();
		theModel.addAttribute("xe", theXe);
		return "xe-form";
	}
	@GetMapping("/delete")
	public String deleteXe(@RequestParam("xeId") int theId) {
		xeService.deleteXe(theId);
		return "redirect:/xe/list";
	}
	@GetMapping("/list")
	public String listXe(Model theModel) {
		List<Xe> theXes = xeService.getXes();
		theModel.addAttribute("xes",theXes);
		return "list-xe";
	}
}






