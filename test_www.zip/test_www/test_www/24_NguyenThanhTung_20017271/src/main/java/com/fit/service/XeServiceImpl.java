package com.fit.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.fit.dao.XeDao;
import com.fit.entity.Xe;

@Service
public class XeServiceImpl implements XeService{

	@Autowired
	private XeDao xeDao;
	
	@Override
	@Transactional
	public void saveXe(Xe theXe) {
		xeDao.saveXe(theXe);
		
	}

	@Override
	@Transactional
	public void deleteXe(int theId) {
		xeDao.deleteXe(theId);
		
	}

	@Override
	@Transactional
	public List<Xe> getXes() {
		
		return xeDao.getXes();
	}

	@Override
	@Transactional
	public Xe getXe(int theId) {
		return xeDao.getXe(theId);
	}

}
