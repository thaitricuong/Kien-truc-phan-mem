package com.fit.dao;

import java.util.List;

import com.fit.entity.Xe;

public interface XeDao {

	public void saveXe(Xe theXe);

	public void deleteXe(int theId);

	public Xe getXe(int theId);

	public List<Xe> getXes();

}
