package com.fit.service;

import java.util.List;

import com.fit.entity.Xe;

public interface XeService {

	public void saveXe(Xe theXe);

	public void deleteXe(int theId);

	public List<Xe> getXes();

	public Xe getXe(int theId);

}
